import  React,{useState} from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable, TextInput } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const HomeScreen1 = () => {
  const navigation = useNavigation();

  const [formData, setFormData] = useState({
    email: '',
    password: ''

  });

  const handleSignUp = () => {
    if (formData.email && formData.password) {

      fetch('http://192.168.94.97:8000/api/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })
        .then(response => response.json())
        .then(data => {
          if (data.error) {
            alert(data.error)
          }
          else {
            alert(data.Success)
            navigation.navigate('HomeScreen2')
          }
        })
        .catch(error => {
          console.error('Error:', error);
          // Display an error message or handle as needed
        });
    } else {
      console.error('Error:');

    }
  };

  return (
    <View style={styles.homeScreen}>
      <Image
        style={styles.book151Icon}
        contentFit="cover"
        source={require("../assets/book15-1.png")}
      />
      <View style={styles.homeScreenChild} />
      <View style={[styles.homeScreenItem, styles.homePosition]} />
      <View style={[styles.homeScreenInner, styles.homePosition]} />
      <TextInput
        style={[styles.enterEmail, styles.enterEmailTypo]}
        placeholder="Enter Email"
        
        onChangeText={text => setFormData({ ...formData, email: text })}
      />

      <TextInput
        style={[styles.createPassword, styles.enterEmailTypo]}
        placeholder="Create Password"
        secureTextEntry
       
        onChangeText={text => setFormData({ ...formData, password: text })}
      />

      {/* <Text style={[styles.createPassword, styles.enterEmailTypo]}>
        <Text style={styles.text}>{` `}</Text>
        <Text style={styles.createPassword1}>Create Password</Text>
      </Text>
      <Text style={[styles.enterEmail, styles.enterEmailTypo]}>
        Enter Email
      </Text> */}
      <Pressable
        style={styles.createAccount}
        onPress={handleSignUp}
      >
        <Text style={[styles.createAccount1, styles.signUpTypo]}>
          {" "}
          Create account
        </Text>
      </Pressable>
      <Text style={[styles.signUp, styles.signUpTypo]}>Sign Up</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  homePosition: {
    left: 26,
    height: 56,
    position: "absolute",
  },
  enterEmailTypo: {
    opacity: 0.5,
    color: Color.colorGray_200,
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  signUpTypo: {
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  book151Icon: {
    top: 756,
    left: 97,
    width: 24,
    height: 24,
    opacity: 0.3,
    position: "absolute",
    overflow: "hidden",
  },
  homeScreenChild: {
    top: 406,
    left: 23,
    height: 56,
    width: 325,
    backgroundColor: Color.colorGainsboro,
    position: "absolute",
  },
  homeScreenItem: {
    top: 492,
    backgroundColor: Color.coffeeRed,
    width: 241,
  },
  homeScreenInner: {
    top: 302,
    width: 325,
    backgroundColor: Color.colorGainsboro,
    left: 26,
  },
  text: {
    fontSize: FontSize.size_5xl,
  },
  createPassword1: {
    fontSize: FontSize.size_3xl,
  },
  createPassword: {
    top: 415,
    left: 42,
    width: 231,
    height: 38,
  },
  enterEmail: {
    top: 315,
    left: 48,
    width: 219,
    height: 31,
    fontSize: FontSize.size_3xl,
  },
  createAccount1: {
    color: Color.colorBlack,
    width: 254,
    opacity: 0.7,
    fontSize: FontSize.size_5xl,
    height: 38,
  },
  createAccount: {
    left: 18,
    top: 510,
    position: "absolute",
  },
  signUp: {
    top: 129,
    left: 114,
    fontSize: FontSize.size_11xl,
    color: Color.coffeeRed,
    width: 139,
    height: 47,
    position: "absolute",
  },
  homeScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeLight,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default HomeScreen1;
