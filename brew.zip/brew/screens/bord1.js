import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Bord1 = () => {
  const navigation = useNavigation();

  const handleSkip = () => {
    navigation.navigate("HomeScreen");
  };

  const handleNext = () => {
    navigation.navigate("Bord2");
  };

  return (
    <View style={styles.container}>
      <View style={styles.wrapper}>
        <Text style={styles.title}>BrewNook</Text>

        <Image
          source={require("../assets/mask-group.png")}
          style={styles.image}
          resizeMode="cover"
        />

        <Text style={styles.description}>
          Let's find your special coffee here...
        </Text>

        <View style={styles.bottomButtons}>
          <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
            <Text style={styles.buttonText}>Skip</Text>
          </TouchableOpacity>

          <View style={styles.dotsContainer}>
            <View
              style={[styles.dot, { backgroundColor: "rgba(220, 69, 19, 1)" }]}
            />
            <View style={styles.dot} />
          </View>

          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.buttonText}>Next</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5E8E4",
    alignItems: "center",
    justifyContent: "center",
  },
  wrapper: {
    width: 360,
    height: 800,
    backgroundColor: "#F5E8E4",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    color: "rgba(220, 69, 19, 1)",
    fontSize: 32,
    fontFamily: "sans-serif",
    fontWeight: "700",
    marginTop: 100,
  },
  image: {
    width: 250,
    height: 183,
    marginTop: 50,
  },
  description: {
    color: "rgba(220, 69, 19, 1)",
    fontSize: 20,
    fontFamily: "sans-serif",
    fontWeight: "700",
    textAlign: "center",
    marginTop: 45,
  },
  bottomButtons: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 50,
  },
  skipButton: {
    width: 66,
    height: 41,
    backgroundColor: "rgba(220, 69, 19, 1)",
    borderRadius: 20.5,
    alignItems: "center",
    justifyContent: "center",
  },
  nextButton: {
    width: 66,
    height: 41,
    backgroundColor: "rgba(220, 69, 19, 1)",
    borderRadius: 20.5,
    marginLeft: 20, // Adjust spacing between buttons as needed
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    color: "black",
    fontSize: 20,
    fontFamily: "sans-serif",
    fontWeight: "400",
  },
  dotsContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 10, // Adjust the margin between dots and buttons as needed
  },
  dot: {
    width: 19,
    height: 13,
    borderRadius: 6.5,
    marginLeft: 10,
    marginRight: 10,
    backgroundColor: "#D9D9D9",
  },
});

export default Bord1;
