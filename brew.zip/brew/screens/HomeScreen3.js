import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const HomeScreen3 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homeScreen}>
      <View style={[styles.homeScreenChild, styles.homeLayout]} />
      <Pressable
        style={styles.homeScreenItem}
        onPress={() => navigation.navigate("HomeScreen")}
      />
      <View style={[styles.homeScreenInner, styles.homeLayout]} />
      <Text style={[styles.profilePhoto, styles.sTypo]}>Profile photo</Text>
      <Text style={[styles.saudSuleman, styles.saudSulemanTypo]}>
        Saud Suleman
      </Text>
      <Text style={[styles.logOut, styles.sTypo]}>Log Out</Text>
      <Text style={[styles.saudgmailcom, styles.saudSulemanTypo]}>
        saud@gmail.com
      </Text>
      <Image
        style={styles.ellipseIcon}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.s, styles.sTypo]}>S</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  homeLayout: {
    height: 56,
    width: 325,
    backgroundColor: Color.colorGainsboro,
    position: "absolute",
  },
  sTypo: {
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  saudSulemanTypo: {
    width: 231,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.archivoBlackRegular,
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  homeScreenChild: {
    top: 483,
    left: 23,
  },
  homeScreenItem: {
    top: 566,
    width: 124,
    height: 37,
    left: 49,
    backgroundColor: Color.colorGainsboro,
    position: "absolute",
  },
  homeScreenInner: {
    top: 406,
    left: 26,
  },
  profilePhoto: {
    top: 297,
    left: 88,
    width: 264,
    height: 28,
    fontSize: FontSize.size_5xl,
    color: Color.colorBlack,
    fontFamily: FontFamily.archivoBlackRegular,
  },
  saudSuleman: {
    top: 423,
    height: 39,
    left: 53,
  },
  logOut: {
    top: 573,
    width: 245,
    height: 30,
    left: 53,
    fontSize: FontSize.size_5xl,
    color: Color.colorBlack,
    fontFamily: FontFamily.archivoBlackRegular,
  },
  saudgmailcom: {
    top: 501,
    height: 38,
    left: 49,
  },
  ellipseIcon: {
    top: 149,
    left: 116,
    width: 114,
    height: 117,
    position: "absolute",
  },
  s: {
    top: 183,
    left: 162,
    fontSize: FontSize.size_11xl,
    width: 47,
    height: 48,
  },
  homeScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeLight,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default HomeScreen3;
