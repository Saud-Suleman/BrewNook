import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Pressable, Text, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const CartScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.cartScreen, styles.iconLayout1]}>
      <Pressable
        style={[styles.arrowCircleLeft51, styles.taxesPosition]}
        onPress={() => navigation.navigate("DetailsScreen")}
      >
        <Image
          style={[styles.icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/arrowcircleleft5-1.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.arrowCircleLeft51, styles.taxesPosition]}
        onPress={() => navigation.navigate("DetailsScreen")}
      >
        <Image
          style={[styles.icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/arrowcircleleft5-1.png")}
        />
      </Pressable>
      <Text style={styles.cart}>Cart</Text>
      <Text style={[styles.myOrder, styles.text4Typo]}>My Order</Text>
      <Text style={[styles.youHave2Container, styles.withMilkTypo]}>
        <Text style={styles.youHave}>{`You have `}</Text>
        <Text style={[styles.items, styles.textTypo2]}>2 items</Text>
        <Text style={styles.youHave}> in your cart.</Text>
      </Text>
      <View style={[styles.groupParent, styles.taxesPosition]}>
        <View style={styles.rectangleLayout}>
          <View style={styles.groupShadowBox} />
          <View style={styles.minusSquare91Parent}>
            <Image
              style={styles.iconLayout}
              contentFit="cover"
              source={require("../assets/minussquare9-1.png")}
            />
            <Text style={[styles.text, styles.textTypo2]}>1</Text>
            <Image
              style={[styles.addSquare41Icon, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/addsquare4-1.png")}
            />
          </View>
          <View style={styles.frameParent}>
            <View>
              <Text style={styles.espresso}>Espresso</Text>
              <Text style={[styles.withMilk, styles.withMilkTypo]}>
                with milk
              </Text>
            </View>
            <Text style={styles.text1}>$2.50</Text>
          </View>
          <Image
            style={styles.maskGroupIcon}
            contentFit="cover"
            source={require("../assets/mask-group.png")}
          />
        </View>
        <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
          <View style={styles.groupShadowBox} />
          <View style={styles.minusSquare91Parent}>
            <Image
              style={styles.iconLayout}
              contentFit="cover"
              source={require("../assets/minussquare9-1.png")}
            />
            <Text style={[styles.text, styles.textTypo2]}>1</Text>
            <Image
              style={[styles.addSquare41Icon, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/addsquare4-1.png")}
            />
          </View>
          <View style={styles.frameParent}>
            <View>
              <Text style={styles.espresso}>Latte</Text>
              <Text style={[styles.withMilk, styles.withMilkTypo]}>
                with bakery
              </Text>
            </View>
            <Text style={styles.text1}>$3.20</Text>
          </View>
          <Image
            style={styles.maskGroupIcon}
            contentFit="cover"
            source={require("../assets/mask-group1.png")}
          />
        </View>
      </View>
      <Text style={[styles.text4, styles.text4Typo]}>$7.7</Text>
      <Pressable
        style={styles.proceedToFavouritsContainer}
        onPress={() => navigation.navigate("HomeScreen4")}
      >
        <Text style={[styles.proceedToFavourits, styles.textTypo2]}>
          Proceed to Favourits
        </Text>
      </Pressable>
      <Text style={[styles.subtotal, styles.taxesPosition]}>Subtotal</Text>
      <Text style={[styles.shippingCost, styles.taxesPosition]}>
        Shipping Cost
      </Text>
      <Text style={[styles.taxes, styles.taxesPosition]}>Taxes</Text>
      <Text style={[styles.total, styles.taxesPosition]}>Total</Text>
      <Text style={[styles.text5, styles.textTypo]}>$1.00</Text>
      <Text style={[styles.text6, styles.textTypo]}>$5.7</Text>
      <View style={[styles.cartScreenChild, styles.cartLayout]} />
      <Text style={[styles.text7, styles.textTypo]}>$1.00</Text>
      <Text style={[styles.text8, styles.textTypo]}>$7.7</Text>
      <View style={[styles.cartScreenItem, styles.cartLayout]} />
      <View style={[styles.cartScreenInner, styles.cartLayout]} />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout1: {
    overflow: "hidden",
    width: "100%",
  },
  taxesPosition: {
    left: 24,
    position: "absolute",
  },
  text4Typo: {
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  withMilkTypo: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  textTypo2: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  iconLayout: {
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  rectangleLayout: {
    height: 96,
    width: 325,
  },
  textTypo: {
    textAlign: "right",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.coffeeRed,
    position: "absolute",
  },
  cartLayout: {
    opacity: 0.1,
    height: 1,
    width: 328,
    borderTopWidth: 1,
    borderColor: Color.coffeeRed,
    borderStyle: "solid",
    left: 24,
    position: "absolute",
  },
  icon: {
    height: "100%",
  },
  arrowCircleLeft51: {
    top: 56,
    width: 40,
    height: 40,
  },
  cart: {
    top: 64,
    left: 162,
    fontSize: FontSize.size_3xl,
    textAlign: "center",
    color: Color.coffeDark,
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  myOrder: {
    top: 128,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: "left",
    left: 27,
    color: Color.coffeDark,
  },
  youHave: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.coffeDark,
  },
  items: {
    color: Color.coffeeRed,
  },
  youHave2Container: {
    top: 166,
    left: 27,
    position: "absolute",
  },
  groupShadowBox: {
    shadowOpacity: 1,
    elevation: 16,
    shadowRadius: 16,
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowColor: "rgba(209, 81, 45, 0.1)",
    backgroundColor: Color.white,
    borderRadius: Border.br_base,
    left: 0,
    top: 0,
    height: 96,
    width: 325,
    position: "absolute",
  },
  text: {
    marginLeft: 8,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    color: Color.coffeDark,
  },
  addSquare41Icon: {
    marginLeft: 8,
  },
  minusSquare91Parent: {
    top: 36,
    left: 228,
    flexDirection: "row",
    alignItems: "center",
    position: "absolute",
  },
  espresso: {
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.coffeDark,
    fontFamily: FontFamily.archivoBlackRegular,
  },
  withMilk: {
    color: Color.coffeeMud,
    marginTop: 4,
    fontFamily: FontFamily.poppinsRegular,
  },
  text1: {
    marginTop: 12,
    fontSize: FontSize.size_sm,
    color: Color.coffeeRed,
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  frameParent: {
    top: 15,
    left: 110,
    position: "absolute",
  },
  maskGroupIcon: {
    top: 8,
    left: 16,
    width: 80,
    height: 80,
    position: "absolute",
  },
  rectangleGroup: {
    marginTop: 16,
  },
  groupParent: {
    top: 208,
  },
  text4: {
    top: 738,
    left: 164,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  proceedToFavourits: {
    fontSize: FontSize.size_sm,
    color: Color.coffeeRed,
    textAlign: "center",
  },
  proceedToFavouritsContainer: {
    left: 115,
    top: 768,
    position: "absolute",
  },
  subtotal: {
    top: 512,
    fontSize: FontSize.size_sm,
    color: Color.coffeeRed,
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  shippingCost: {
    top: 565,
    fontSize: FontSize.size_sm,
    color: Color.coffeeRed,
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  taxes: {
    top: 618,
    fontSize: FontSize.size_sm,
    color: Color.coffeeRed,
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  total: {
    top: 671,
    fontSize: FontSize.size_sm,
    color: Color.coffeeRed,
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  text5: {
    left: 315,
    textAlign: "right",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    top: 565,
  },
  text6: {
    left: 321,
    top: 512,
  },
  cartScreenChild: {
    top: 602,
  },
  text7: {
    left: 315,
    textAlign: "right",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    top: 618,
  },
  text8: {
    left: 322,
    top: 671,
  },
  cartScreenItem: {
    top: 549,
  },
  cartScreenInner: {
    top: 655,
  },
  cartScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeLight,
    flex: 1,
    height: 812,
  },
});

export default CartScreen;
