import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const HomeScreen4 = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={styles.homeScreen}
      onPress={() => navigation.navigate("CartScreen")}
    >
      <View style={styles.brewnookWrapper}>
        <Text style={[styles.brewnook, styles.latteTypo]}>BrewNook</Text>
      </View>
      <View style={[styles.homeScreenInner, styles.rectangleGroupPosition]}>
        <View style={styles.rectangleLayout}>
          <View style={styles.groupShadowBox} />
          <Image
            style={[styles.maskGroupIcon, styles.maskGroupPosition]}
            contentFit="cover"
            source={require("../assets/mask-group2.png")}
          />
          <View style={styles.latteParent}>
            <Text style={[styles.latte, styles.latteTypo]}>Latte</Text>
            <Text style={[styles.withBakery, styles.text1Typo]}>
              with bakery
            </Text>
          </View>
          <Text style={[styles.text, styles.textTypo]}>$3.20</Text>
          <View style={[styles.star1Parent, styles.star1FlexBox]}>
            <Image
              style={styles.star1Icon}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
          </View>
        </View>
      </View>
      <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
        <View style={styles.groupShadowBox} />
        <Image
          style={[styles.maskGroupIcon1, styles.maskGroupPosition]}
          contentFit="cover"
          source={require("../assets/mask-group3.png")}
        />
        <View style={[styles.americanoParent, styles.home52Layout]}>
          <Text style={[styles.latte, styles.latteTypo]}>Americano</Text>
          <Text style={[styles.withBakery, styles.text1Typo]}>
            with whole milk
          </Text>
        </View>
        <Text style={[styles.text2, styles.text2Layout]}>$7.00</Text>
        <View style={[styles.star1Group, styles.star1FlexBox]}>
          <Image
            style={styles.star1Icon}
            contentFit="cover"
            source={require("../assets/star-11.png")}
          />
          <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
        </View>
      </View>
      <View style={[styles.homeScreenChild, styles.groupViewPosition]}>
        <View style={styles.groupViewLayout}>
          <View style={[styles.groupInner, styles.groupInnerShadowBox]} />
          <Image
            style={[styles.maskGroupIcon1, styles.maskGroupPosition]}
            contentFit="cover"
            source={require("../assets/mask-group4.png")}
          />
          <View style={[styles.cappucinoParent, styles.parentPosition]}>
            <Text style={[styles.latte, styles.latteTypo]}>Cappucino</Text>
            <Text style={[styles.withBakery, styles.text1Typo]}>
              2% milk, wet
            </Text>
          </View>
          <Text style={[styles.text4, styles.textTypo]}>$5.99</Text>
          <View style={[styles.star1Container, styles.star1FlexBox]}>
            <Image
              style={styles.star1Icon}
              contentFit="cover"
              source={require("../assets/star-12.png")}
            />
            <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
          </View>
        </View>
      </View>
      <View style={[styles.groupView, styles.groupViewLayout]}>
        <View style={[styles.rectangleView, styles.groupInnerShadowBox]} />
        <Image
          style={[styles.maskGroupIcon1, styles.maskGroupPosition]}
          contentFit="cover"
          source={require("../assets/mask-group5.png")}
        />
        <View style={[styles.espressoParent, styles.parentPosition]}>
          <Text style={[styles.latte, styles.latteTypo]}>Espresso</Text>
          <Text style={[styles.withBakery, styles.text1Typo]}>with milk</Text>
        </View>
        <Text style={[styles.text6, styles.textTypo]}>$2.50</Text>
        <View style={[styles.star1Container, styles.star1FlexBox]}>
          <Image
            style={styles.star1Icon}
            contentFit="cover"
            source={require("../assets/star-13.png")}
          />
          <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
        </View>
      </View>
      <Image
        style={[styles.heart102Icon, styles.iconLayout2]}
        contentFit="cover"
        source={require("../assets/heart10-2.png")}
      />
      <Image
        style={[styles.heart104Icon, styles.iconLayout2]}
        contentFit="cover"
        source={require("../assets/heart10-2.png")}
      />
      <Image
        style={[styles.heart105Icon, styles.iconLayout2]}
        contentFit="cover"
        source={require("../assets/heart10-2.png")}
      />
      <Image
        style={[styles.heart103Icon, styles.iconLayout2]}
        contentFit="cover"
        source={require("../assets/heart10-2.png")}
      />
      <Pressable
        style={styles.vector}
        onPress={() => navigation.navigate("CartScreen")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector.png")}
        />
      </Pressable>
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("HomeScreen5")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/ellipse-3.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.home52, styles.home52Layout]}
        onPress={() => navigation.navigate("HomeScreen5")}
      >
        <Image
          style={[styles.icon2, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/home5-11.png")}
        />
      </Pressable>
      <Pressable
        style={styles.arrowCircleLeft53}
        onPress={() => navigation.navigate("CartScreen")}
      >
        <Image
          style={[styles.icon2, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/arrowcircleleft5-1.png")}
        />
      </Pressable>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Pressable
        style={[styles.container, styles.text2Layout]}
        onPress={() => navigation.navigate("DetailsScreen")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/ellipse-13.png")}
        />
      </Pressable>
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <Pressable
        style={styles.frame}
        onPress={() => navigation.navigate("HomeScreen3")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/ellipse-14.png")}
        />
      </Pressable>
      <Image
        style={[styles.vectorIcon3, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector4.png")}
      />
      <Image
        style={[styles.vectorIcon4, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector5.png")}
      />
    </Pressable>
  );
};

const styles = StyleSheet.create({
  latteTypo: {
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
    color: Color.coffeDark,
  },
  rectangleGroupPosition: {
    top: 465,
    position: "absolute",
  },
  maskGroupPosition: {
    width: 72,
    left: 28,
    top: 0,
    position: "absolute",
  },
  text1Typo: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  textTypo: {
    height: 11,
    width: 43,
    fontSize: FontSize.size_sm,
    left: 16,
    textAlign: "left",
    color: Color.coffeDark,
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  star1FlexBox: {
    alignItems: "center",
    left: 16,
    flexDirection: "row",
    position: "absolute",
  },
  rectangleLayout: {
    height: 175,
    width: 128,
  },
  home52Layout: {
    height: 32,
    position: "absolute",
  },
  text2Layout: {
    width: 43,
    position: "absolute",
  },
  groupViewPosition: {
    top: 169,
    position: "absolute",
  },
  groupInnerShadowBox: {
    shadowOpacity: 1,
    elevation: 24,
    shadowRadius: 24,
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowColor: "rgba(209, 81, 45, 0.16)",
    backgroundColor: Color.white,
    borderRadius: Border.br_5xl,
    left: 0,
    width: 128,
    position: "absolute",
  },
  parentPosition: {
    height: 29,
    left: 16,
    position: "absolute",
  },
  groupViewLayout: {
    height: 172,
    width: 128,
  },
  iconLayout2: {
    opacity: 0.3,
    height: 42,
    width: 46,
    position: "absolute",
    overflow: "hidden",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  iconLayout1: {
    height: "100%",
    width: "100%",
  },
  vectorIconLayout: {
    width: "2.48%",
    bottom: "5.07%",
    top: "92.73%",
    height: "2.19%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  brewnook: {
    top: "0%",
    left: "0%",
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  brewnookWrapper: {
    height: "3.2%",
    width: "36.53%",
    top: "7.27%",
    right: "29.87%",
    bottom: "89.53%",
    left: "33.6%",
    position: "absolute",
  },
  groupShadowBox: {
    height: 137,
    top: 38,
    shadowOpacity: 1,
    elevation: 24,
    shadowRadius: 24,
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowColor: "rgba(209, 81, 45, 0.16)",
    backgroundColor: Color.white,
    borderRadius: Border.br_5xl,
    left: 0,
    width: 128,
    position: "absolute",
  },
  maskGroupIcon: {
    height: 61,
  },
  latte: {
    fontSize: FontSize.size_base,
  },
  withBakery: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorBlack,
    marginTop: 4,
  },
  latteParent: {
    height: 28,
    left: 16,
    top: 76,
    position: "absolute",
  },
  text: {
    top: 117,
  },
  star1Icon: {
    width: 14,
    height: 14,
    overflow: "hidden",
  },
  text1: {
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    marginLeft: 4,
    color: Color.coffeDark,
    fontSize: FontSize.size_xs,
  },
  star1Parent: {
    top: 137,
    height: 13,
    alignItems: "center",
  },
  homeScreenInner: {
    width: 138,
    height: 165,
    flexDirection: "row",
    left: 26,
  },
  maskGroupIcon1: {
    height: 60,
  },
  americanoParent: {
    top: 78,
    left: 16,
  },
  text2: {
    top: 126,
    height: 12,
    fontSize: FontSize.size_sm,
    width: 43,
    left: 16,
    textAlign: "left",
    color: Color.coffeDark,
    fontFamily: FontFamily.archivoBlackRegular,
  },
  star1Group: {
    top: 150,
    height: 15,
  },
  rectangleGroup: {
    left: 223,
    top: 465,
    position: "absolute",
  },
  groupInner: {
    top: 37,
    height: 135,
  },
  cappucinoParent: {
    top: 77,
  },
  text4: {
    top: 120,
  },
  star1Container: {
    top: 141,
    height: 13,
    alignItems: "center",
  },
  homeScreenChild: {
    height: 181,
    left: 223,
    flexDirection: "row",
  },
  rectangleView: {
    top: 36,
    height: 136,
  },
  espressoParent: {
    top: 76,
  },
  text6: {
    top: 119,
  },
  groupView: {
    top: 169,
    position: "absolute",
    left: 26,
  },
  heart102Icon: {
    left: 64,
    opacity: 0.3,
    height: 42,
    width: 46,
    top: 356,
  },
  heart104Icon: {
    top: 648,
    left: 64,
    opacity: 0.3,
    height: 42,
    width: 46,
  },
  heart105Icon: {
    top: 643,
    left: 264,
  },
  heart103Icon: {
    left: 261,
    top: 356,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  vector: {
    left: "9.07%",
    top: "95.44%",
    right: "86.21%",
    bottom: "2.09%",
    width: "4.72%",
    height: "2.46%",
    position: "absolute",
  },
  wrapper: {
    left: 145,
    top: 701,
    width: 80,
    height: 80,
    position: "absolute",
  },
  icon2: {
    overflow: "hidden",
  },
  home52: {
    left: 169,
    top: 724,
    width: 32,
  },
  arrowCircleLeft53: {
    left: 22,
    top: 52,
    width: 40,
    height: 40,
    position: "absolute",
  },
  vectorIcon: {
    width: "5.33%",
    right: "24.27%",
    left: "70.4%",
    bottom: "5.07%",
    top: "92.73%",
    height: "2.19%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  container: {
    left: 69,
    top: 740,
    height: 41,
  },
  vectorIcon1: {
    right: "76.19%",
    left: "21.33%",
  },
  vectorIcon2: {
    right: "73.25%",
    left: "24.27%",
  },
  frame: {
    left: 312,
    top: 762,
    width: 39,
    height: 36,
    position: "absolute",
  },
  vectorIcon3: {
    height: "1.23%",
    width: "2.67%",
    top: "94.83%",
    right: "10.13%",
    bottom: "3.94%",
    left: "87.2%",
    position: "absolute",
  },
  vectorIcon4: {
    height: "0.99%",
    width: "4.85%",
    top: "96.55%",
    right: "9.01%",
    bottom: "2.46%",
    left: "86.13%",
    position: "absolute",
  },
  homeScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeLight,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default HomeScreen4;
