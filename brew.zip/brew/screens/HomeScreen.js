import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Pressable, Text, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const HomeScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homeScreen}>
      <Image
        style={styles.heart101Icon}
        contentFit="cover"
        source={require("../assets/heart10-1.png")}
      />
      <Pressable
        style={styles.coffee1}
        onPress={() => navigation.navigate("HomeScreen2")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/coffee-1.png")}
        />
      </Pressable>
      <Text style={[styles.app, styles.appTypo]}>BrewNook</Text>
      <Pressable
        style={styles.appPosition}
        onPress={() => navigation.navigate("HomeScreen2")}
      >
        <Text style={[styles.brewnook1, styles.appTypo]}>BrewNook</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  appTypo: {
    height: 42,
    width: 159,
    textAlign: "left",
    fontFamily: FontFamily.architectsDaughterRegular,
    fontSize: FontSize.size_11xl,
  },
  heart101Icon: {
    top: 756,
    left: 253,
    width: 24,
    height: 24,
    opacity: 0.3,
    position: "absolute",
    overflow: "hidden",
  },
  icon: {
    borderRadius: 200,
    height: "100%",
    width: "100%",
  },
  coffee1: {
    left: 38,
    top: 258,
    width: 300,
    height: 200,
    position: "absolute",
  },
  app: {
    color: Color.white,
    left: 116,
    top: 482,
    position: "absolute",
  },
  brewnook1: {
    color: Color.colorBlack,
  },
  appPosition: {
    left: 116,
    top: 482,
    position: "absolute",
  },
  homeScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeRed,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default HomeScreen;
