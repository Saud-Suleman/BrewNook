import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const HomeScreen5 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homeScreen}>
      <View style={styles.brewnookWrapper}>
        <Text style={[styles.brewnook, styles.textTypo]}>BrewNook</Text>
      </View>
      <Text style={styles.welcomeSaudSulemanContainer}>
        <Text style={styles.welcome}>{`Welcome,
`}</Text>
        <Text style={styles.saudSuleman}>Saud Suleman</Text>
      </Text>
      <Pressable
        style={styles.frameParent}
        onPress={() => navigation.navigate("DetailsScreen")}
      >
        <View style={styles.groupParent}>
          <View style={styles.rectangleLayout}>
            <View style={styles.groupChildShadowBox} />
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group6.png")}
            />
            <View style={[styles.espressoParent, styles.parentPosition]}>
              <Text style={[styles.espresso, styles.textTypo]}>Espresso</Text>
              <Text style={[styles.withMilk, styles.text1Typo]}>with milk</Text>
            </View>
            <Text style={[styles.text, styles.parentPosition]}>$2.50</Text>
            <View style={[styles.star1Parent, styles.parentPosition]}>
              <Image
                style={styles.star1Icon}
                contentFit="cover"
                source={require("../assets/star-131.png")}
              />
              <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
            </View>
            <View style={[styles.rectangleGroup, styles.groupLayout]}>
              <View style={[styles.groupItem, styles.groupLayout]} />
              <Image
                style={[styles.fiRrPlusSmall11Icon, styles.book151Layout]}
                contentFit="cover"
                source={require("../assets/firrplussmall1-1.png")}
              />
            </View>
          </View>
          <View style={[styles.rectangleContainer, styles.rectangleLayout]}>
            <View style={styles.groupChildShadowBox} />
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group7.png")}
            />
            <View style={[styles.espressoParent, styles.parentPosition]}>
              <Text style={[styles.espresso, styles.textTypo]}>Cappucino</Text>
              <Text style={[styles.withMilk, styles.text1Typo]}>
                2% milk, wet
              </Text>
            </View>
            <Text style={[styles.text, styles.parentPosition]}>$5.99</Text>
            <View style={[styles.star1Parent, styles.parentPosition]}>
              <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
              <Image
                style={styles.star1Icon}
                contentFit="cover"
                source={require("../assets/star-131.png")}
              />
            </View>
            <View style={[styles.rectangleGroup, styles.groupLayout]}>
              <View style={[styles.groupItem, styles.groupLayout]} />
              <Image
                style={[styles.fiRrPlusSmall11Icon, styles.book151Layout]}
                contentFit="cover"
                source={require("../assets/firrplussmall1-1.png")}
              />
            </View>
          </View>
        </View>
        <View style={styles.groupContainer}>
          <View style={styles.rectangleLayout}>
            <View style={styles.groupChildShadowBox} />
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group8.png")}
            />
            <View style={[styles.espressoParent, styles.parentPosition]}>
              <Text style={[styles.espresso, styles.textTypo]}>Latte</Text>
              <Text style={[styles.withMilk, styles.text1Typo]}>
                with bakery
              </Text>
            </View>
            <Text style={[styles.text, styles.parentPosition]}>$3.20</Text>
            <View style={[styles.star1Parent, styles.parentPosition]}>
              <Image
                style={styles.star1Icon}
                contentFit="cover"
                source={require("../assets/star-131.png")}
              />
              <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
            </View>
            <View style={[styles.rectangleGroup, styles.groupLayout]}>
              <View style={[styles.groupItem, styles.groupLayout]} />
              <Image
                style={[styles.fiRrPlusSmall11Icon, styles.book151Layout]}
                contentFit="cover"
                source={require("../assets/firrplussmall1-1.png")}
              />
            </View>
          </View>
          <View style={[styles.rectangleContainer, styles.rectangleLayout]}>
            <View style={styles.groupChildShadowBox} />
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group9.png")}
            />
            <View style={[styles.espressoParent, styles.parentPosition]}>
              <Text style={[styles.espresso, styles.textTypo]}>Americano</Text>
              <Text style={[styles.withMilk, styles.text1Typo]}>
                with whole milk
              </Text>
            </View>
            <Text style={[styles.text, styles.parentPosition]}>$7.00</Text>
            <View style={[styles.star1Parent, styles.parentPosition]}>
              <Image
                style={styles.star1Icon}
                contentFit="cover"
                source={require("../assets/star-131.png")}
              />
              <Text style={[styles.text1, styles.text1Typo]}>4.5</Text>
            </View>
            <View style={[styles.rectangleGroup, styles.groupLayout]}>
              <View style={[styles.groupItem, styles.groupLayout]} />
              <Image
                style={[styles.fiRrPlusSmall11Icon, styles.book151Layout]}
                contentFit="cover"
                source={require("../assets/firrplussmall1-1.png")}
              />
            </View>
          </View>
        </View>
      </Pressable>
      <Pressable
        style={styles.vector}
        onPress={() => navigation.navigate("CartScreen")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.book151, styles.book151Layout]}
        onPress={() => navigation.navigate("DetailsScreen")}
      >
        <Image
          style={[styles.icon1, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/book15-11.png")}
        />
      </Pressable>
      <Image
        style={styles.homeScreenChild}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Image
        style={styles.home51Icon}
        contentFit="cover"
        source={require("../assets/home5-11.png")}
      />
      <Pressable
        style={styles.vector1}
        onPress={() => navigation.navigate("HomeScreen4")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector1.png")}
        />
      </Pressable>
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("HomeScreen3")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/ellipse-12.png")}
        />
      </Pressable>
      <Image
        style={[styles.vectorIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector5.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector4.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    fontFamily: FontFamily.archivoBlackRegular,
    textAlign: "left",
    color: Color.coffeDark,
  },
  parentPosition: {
    left: 16,
    position: "absolute",
  },
  text1Typo: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  groupLayout: {
    height: 40,
    width: 40,
    position: "absolute",
  },
  book151Layout: {
    height: 24,
    width: 24,
    position: "absolute",
  },
  rectangleLayout: {
    height: 223,
    width: 128,
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  iconLayout1: {
    height: "100%",
    width: "100%",
  },
  brewnook: {
    top: "0%",
    left: "0%",
    textAlign: "left",
    color: Color.coffeDark,
    fontSize: FontSize.size_5xl,
    height: "100%",
    width: "100%",
    position: "absolute",
  },
  brewnookWrapper: {
    height: "3.2%",
    width: "36.53%",
    top: "6.9%",
    right: "31.2%",
    bottom: "89.9%",
    left: "32.27%",
    position: "absolute",
  },
  welcome: {
    color: Color.coffeeRed,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
  },
  saudSuleman: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.coffeDark,
    fontSize: FontSize.size_5xl,
  },
  welcomeSaudSulemanContainer: {
    height: "7.51%",
    width: "48%",
    top: "14.66%",
    left: "6.4%",
    lineHeight: 32,
    textAlign: "left",
    position: "absolute",
  },
  groupChildShadowBox: {
    height: 183,
    shadowOpacity: 1,
    elevation: 24,
    shadowRadius: 24,
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowColor: "rgba(209, 81, 45, 0.16)",
    backgroundColor: Color.white,
    borderRadius: Border.br_5xl,
    top: 40,
    left: 0,
    width: 128,
    position: "absolute",
  },
  maskGroupIcon: {
    left: 28,
    width: 72,
    height: 72,
    top: 0,
    position: "absolute",
  },
  espresso: {
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.coffeDark,
  },
  withMilk: {
    color: Color.coffeeMud,
    marginTop: 4,
    fontFamily: FontFamily.poppinsRegular,
  },
  espressoParent: {
    top: 94,
  },
  text: {
    top: 152,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.coffeDark,
    fontFamily: FontFamily.archivoBlackRegular,
  },
  star1Icon: {
    width: 14,
    height: 14,
    overflow: "hidden",
  },
  text1: {
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    marginLeft: 4,
    color: Color.coffeDark,
  },
  star1Parent: {
    top: 181,
    alignItems: "center",
    flexDirection: "row",
  },
  groupItem: {
    borderTopLeftRadius: Border.br_5xl,
    borderBottomRightRadius: Border.br_5xl,
    backgroundColor: Color.coffeeRed,
    top: 0,
    left: 0,
    width: 40,
  },
  fiRrPlusSmall11Icon: {
    top: 8,
    left: 8,
    overflow: "hidden",
  },
  rectangleGroup: {
    top: 183,
    left: 88,
  },
  rectangleContainer: {
    marginLeft: 16,
  },
  groupParent: {
    flexDirection: "row",
  },
  groupContainer: {
    marginTop: 24,
    flexDirection: "row",
  },
  frameParent: {
    top: 217,
    left: 50,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  vector: {
    left: "6.93%",
    top: "95.69%",
    right: "88.35%",
    bottom: "1.85%",
    width: "4.72%",
    height: "2.46%",
    position: "absolute",
  },
  icon1: {
    overflow: "hidden",
  },
  book151: {
    left: 83,
    // top: 759,
    top: 800,
  },
  homeScreenChild: {
    top: 708,
    left: 148,
    width: 80,
    height: 80,
    position: "absolute",
  },
  home51Icon: {
    top: 729,
    left: 172,
    width: 32,
    height: 32,
    position: "absolute",
    overflow: "hidden",
  },
  vector1: {
    left: "68.8%",
    top: "93.47%",
    right: "25.87%",
    bottom: "4.33%",
    width: "5.33%",
    height: "2.19%",
    position: "absolute",
  },
  wrapper: {
    left: 308,
    top: 758,
    width: 47,
    height: 42,
    position: "absolute",
  },
  vectorIcon: {
    height: "0.99%",
    width: "4.85%",
    top: "97.04%",
    right: "9.01%",
    bottom: "1.97%",
    left: "86.13%",
    position: "absolute",
  },
  vectorIcon1: {
    height: "1.23%",
    width: "2.67%",
    top: "95.44%",
    right: "10.13%",
    bottom: "3.33%",
    left: "87.2%",
    position: "absolute",
  },
  homeScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeLight,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default HomeScreen5;
