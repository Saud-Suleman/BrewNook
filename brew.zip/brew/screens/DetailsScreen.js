import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const DetailsScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.detailsScreen, styles.iconLayout2]}>
      <Image
        style={[
          styles.picharaBannAiwc4dbjvgeUnsplIcon,
          styles.detailsScreenChildPosition,
        ]}
        contentFit="cover"
        source={require("../assets/picharabannaiwc4dbjvgeunsplash-2.png")}
      />
      <LinearGradient
        style={[styles.detailsScreenChild, styles.detailsScreenChildPosition]}
        locations={[0, 0.32, 1]}
        colors={["#000", "rgba(0, 0, 0, 0.42)", "rgba(0, 0, 0, 0)"]}
      />
      <Pressable
        style={[styles.arrowCircleLeft51, styles.iconLayout1]}
        onPress={() => navigation.navigate("HomeScreen5")}
      >
        <Image
          style={[styles.icon, styles.iconLayout2]}
          contentFit="cover"
          source={require("../assets/arrowcircleleft5-11.png")}
        />
      </Pressable>
      <Text style={[styles.cappucino, styles.textTypo]}>Cappucino</Text>
      <Text style={styles.ingredients}>Ingredients</Text>
      <Text style={[styles.coffeeSize, styles.text1Clr]}>Coffee Size</Text>
      <Text style={[styles.text, styles.textTypo]}>$5.99</Text>
      <Image
        style={styles.ellipse5Stroke}
        contentFit="cover"
        source={require("../assets/ellipse-5-stroke.png")}
      />
      <Image
        style={[styles.detailsScreenItem, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/ellipse-6.png")}
      />
      <Image
        style={[styles.detailsScreenInner, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-7.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-7.png")}
      />
      <Image
        style={[styles.milk31Icon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/milk3-1.png")}
      />
      <Text style={[styles.milk, styles.milkTypo]}>Milk</Text>
      <View style={[styles.frameParent, styles.parentFlexBox]}>
        <View style={styles.groupParent}>
          <View style={styles.groupChildLayout}>
            <View style={[styles.groupChild, styles.groupPosition]} />
            <Image
              style={[styles.paperCup1Icon, styles.paperIconPosition]}
              contentFit="cover"
              source={require("../assets/papercup-1.png")}
            />
          </View>
          <Text style={[styles.small, styles.smallTypo]}>Small</Text>
        </View>
        <View style={styles.groupContainer}>
          <View style={styles.groupLayout}>
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Image
              style={[styles.paperCup2Icon, styles.paperIconPosition]}
              contentFit="cover"
              source={require("../assets/papercup-2.png")}
            />
          </View>
          <Text style={styles.smallTypo}>Medium</Text>
        </View>
        <View style={styles.groupContainer}>
          <View style={styles.groupInnerLayout}>
            <View style={[styles.groupInner, styles.groupInnerLayout]} />
            <Image
              style={styles.paperCup3Icon}
              contentFit="cover"
              source={require("../assets/papercup-3.png")}
            />
          </View>
          <Text style={[styles.small, styles.smallTypo]}>Large</Text>
        </View>
      </View>
      <View style={[styles.minusSquare91Parent, styles.parentFlexBox]}>
        <Image
          style={[styles.minusSquare91Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/minussquare9-11.png")}
        />
        <Text style={[styles.text1, styles.milkTypo]}>5</Text>
        <Image
          style={[styles.addSquare41Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/addsquare4-11.png")}
        />
      </View>
      <Pressable
        style={styles.addToCartContainer}
        onPress={() => navigation.navigate("CartScreen")}
      >
        <Text style={[styles.addToCart, styles.milkTypo]}>Add to Cart</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout2: {
    width: "100%",
    overflow: "hidden",
  },
  detailsScreenChildPosition: {
    height: 350,
    left: 0,
    top: 0,
    position: "absolute",
  },
  iconLayout1: {
    height: 40,
    width: 40,
  },
  textTypo: {
    textAlign: "center",
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  text1Clr: {
    color: Color.coffeDark,
    fontSize: FontSize.size_lg,
  },
  ellipseIconLayout: {
    height: 16,
    width: 16,
    top: 396,
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 24,
  },
  milkTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "center",
  },
  parentFlexBox: {
    flexDirection: "row",
    position: "absolute",
  },
  groupPosition: {
    backgroundColor: Color.white,
    borderRadius: Border.br_base,
    left: 0,
    top: 0,
    position: "absolute",
  },
  paperIconPosition: {
    left: 20,
    top: 20,
    position: "absolute",
    overflow: "hidden",
  },
  smallTypo: {
    marginTop: 16,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
    color: Color.coffeDark,
    textAlign: "center",
  },
  groupLayout: {
    height: 80,
    width: 80,
  },
  groupInnerLayout: {
    height: 104,
    width: 104,
  },
  picharaBannAiwc4dbjvgeUnsplIcon: {
    width: 525,
  },
  detailsScreenChild: {
    width: 375,
    backgroundColor: "transparent",
    opacity: 0.5,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  arrowCircleLeft51: {
    top: 56,
    left: 24,
    position: "absolute",
  },
  cappucino: {
    top: 63,
    left: 124,
    fontSize: FontSize.size_3xl,
    color: Color.white,
  },
  ingredients: {
    top: 280,
    color: Color.coffeeRed,
    fontSize: FontSize.size_lg,
    left: 132,
    textAlign: "center",
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  coffeeSize: {
    top: 453,
    left: 132,
    color: Color.coffeDark,
    textAlign: "center",
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  text: {
    top: 746,
    left: 158,
    fontSize: FontSize.size_xl,
    color: Color.colorBlack,
  },
  ellipse5Stroke: {
    top: 356,
    left: 5,
    width: 365,
    height: 125,
    opacity: 0.3,
    position: "absolute",
  },
  detailsScreenItem: {
    top: 338,
    left: 168,
    position: "absolute",
  },
  detailsScreenInner: {
    left: 319,
  },
  ellipseIcon: {
    left: 39,
  },
  milk31Icon: {
    top: 346,
    left: 176,
    position: "absolute",
    overflow: "hidden",
  },
  milk: {
    top: 394,
    left: 173,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    color: Color.coffeeRed,
    position: "absolute",
  },
  groupChild: {
    height: 64,
    width: 64,
  },
  paperCup1Icon: {
    height: 24,
    width: 24,
  },
  groupChildLayout: {
    height: 64,
    width: 64,
  },
  small: {
    opacity: 0.5,
  },
  groupParent: {
    alignItems: "center",
  },
  groupItem: {
    backgroundColor: Color.coffeeRed,
    borderRadius: Border.br_base,
    width: 80,
    left: 0,
    top: 0,
    position: "absolute",
  },
  paperCup2Icon: {
    height: 40,
    width: 40,
  },
  groupContainer: {
    marginLeft: 40,
    alignItems: "center",
  },
  groupInner: {
    backgroundColor: Color.white,
    borderRadius: Border.br_base,
    left: 0,
    top: 0,
    position: "absolute",
  },
  paperCup3Icon: {
    top: 24,
    width: 56,
    height: 56,
    left: 24,
    position: "absolute",
    overflow: "hidden",
  },
  frameParent: {
    top: 497,
    alignItems: "flex-end",
    left: 24,
  },
  minusSquare91Icon: {
    overflow: "hidden",
  },
  text1: {
    marginLeft: 12,
    color: Color.coffeDark,
    fontSize: FontSize.size_lg,
  },
  addSquare41Icon: {
    marginLeft: 12,
    overflow: "hidden",
  },
  minusSquare91Parent: {
    top: 668,
    left: 129,
    alignItems: "center",
  },
  addToCart: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    color: Color.coffeeRed,
  },
  addToCartContainer: {
    left: 147,
    top: 776,
    position: "absolute",
  },
  detailsScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeLight,
    flex: 1,
    height: 812,
    overflow: "hidden",
  },
});

export default DetailsScreen;
