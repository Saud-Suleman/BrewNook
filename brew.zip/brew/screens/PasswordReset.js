import React,{useState
} from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

const PasswordReset = () => {
  const navigation = useNavigation();
  const [formData, setFormData] = useState({

    email: '',
    code: '',
    password: ''

  });



  const inputFieldWidth = windowWidth * 0.8;
  const inputFieldHeight = windowHeight * 0.1; const sendcode = () => {
    if (formData.email) {

      fetch('http://192.168.94.97:8000/api/validateemail', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })
        .then(response => response.json())
        .then(data => {
          if (data.error) {
            alert(data.error)
          }
          else {
            alert(data.response)
          }
        })
        .catch(error => {
          console.error('Error:', error);
          // Display an error message or handle as needed
        });
    } else {
      console.error('Error:');

    }
  };
  const newpassword = () => {
    if (formData.code && formData.password) {

      fetch('http://192.168.94.97:8000/api/validateemail/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })
        .then(response => response.json())
        .then(data => {
          if (data.error) {
            alert(data.error)
            alert("Can't Successful ")
          }
          else {
            alert(data.response)
            navigation.navigate('HomeScreen2');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          // Display an error message or handle as needed
        });
    } else {
      console.error('Error:');

    }
  };


  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reset Password</Text>

      <TextInput
        style={styles.inputField}
        placeholder="Email"
        secureTextEntry={true}
        onChangeText={text => setFormData({ ...formData, email: text })}
      />

      <TouchableOpacity
        style={styles.sendcodeButton}
        onPress={sendcode}
      >
        <Text style={styles.sendcodeText}>Send the code</Text>
      </TouchableOpacity>

      <TextInput
        style={styles.inputField}
        placeholder="Code"
        secureTextEntry={true}
        onChangeText={text => setFormData({ ...formData, code: text })}
      />

      <TextInput
        style={styles.inputField}
        placeholder="Password"
        secureTextEntry={true}
        onChangeText={text => setFormData({ ...formData, password: text })}
      />

      <TouchableOpacity
        style={styles.submitButton}
        onPress={newpassword}
      >
        <Text style={styles.submitText}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-start",
    backgroundColor: "#F5E8E4",
    padding: windowWidth * 0.05,
  },
  title: {
    color: "rgba(220, 69, 19, 1)",
    fontSize: 24,
    fontWeight: "bold",
    marginTop: windowHeight * 0.02,
    marginBottom: windowHeight * 0.02,
  },

  inputField: {
    width: "100%",
    height: windowHeight * 0.1,
    backgroundColor: "#F5E8E4",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 5,
    marginVertical: windowHeight * 0.01,
    paddingHorizontal: windowHeight * 0.02,
    borderRadius: windowHeight * 0.01,
  },
  submitButton: {
    width: windowWidth * 0.5,
    height: windowHeight * 0.07,
    backgroundColor: "rgba(220, 69, 19, 1)",
    marginTop: windowHeight * 0.05,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
  },
  submitText: {
    color: "black",
    fontWeight: "bold",
    fontSize: 20,
    fontFamily: "sans-serif",
  },
  sendcodeButton: {
    width: windowWidth * 0.5,
    height: windowHeight * 0.07,
    backgroundColor: "rgba(220, 69, 19, 1)",
    marginTop: windowHeight * 0.02, // Adjust this value for proper spacing
    marginBottom: windowHeight * 0.03, // Adjust this value for proper spacing
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
  },
  sendcodeText: {
    color: "black",
    fontWeight: "bold",
    fontSize: 20,
    fontFamily: "sans-serif",
  },
});

export default PasswordReset;
