import  React,{useState} from "react";
import { StyleSheet, View, Pressable, Text, TextInput } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const HomeScreen2 = () => {
  const navigation = useNavigation();
  const [formData, setFormData] = useState({

    email: '',
    password: ''

  });
  const handlelogin = () => {
    if (formData.email && formData.password) {

      fetch('http://192.168.94.97:8000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })
        .then(response => response.json())
        .then(data => {
          if (data.error) {
            alert(data.error)
            return;
          }
          else {

                navigation.navigate("HomeScreen5")
            // Save the received token to AsyncStorage
          }
        })

          
        
        .catch(error => {
          console.error('Error:', error);
          // Display an error message or handle as needed
        });
      }
     else {
      console.error('Error:');

    }
  };

  
  return (
    <View style={styles.homeScreen}>
      <View style={[styles.homeScreenChild, styles.homeLayout]} />
      <View style={[styles.homeScreenItem, styles.homeLayout]} />
      <Pressable
        style={[styles.homeScreenInner, styles.rectangleViewPosition]}
        onPress={handlelogin}
      />
      <View style={[styles.rectangleView, styles.rectangleViewPosition]} />
      <Text style={[styles.logIn, styles.logTypo]}>Log In</Text>

      <Pressable
        style={styles.forgotPasswordLink}
        onPress={() => navigation.navigate("PasswordReset")}
      >
        <Text style={[styles.forgotPasswordText, styles.logTypo]}>
          Forgot Password?
        </Text>
      </Pressable>

      <TextInput
        style={[styles.emailAddress, styles.passwordTypo]}
        placeholder="Email Address"
    
        onChangeText={text => setFormData({ ...formData, email: text })}
      />
      <TextInput
        style={[styles.password, styles.passwordTypo]}
        placeholder="Password"
        secureTextEntry
       
        onChangeText={text => setFormData({ ...formData, password: text })}
      />

      {/* <Text style={[styles.password, styles.passwordTypo]}>Password</Text>
      <Text style={[styles.emailAddress, styles.passwordTypo]}>
        Email Address
      </Text> */}
      <Pressable
        style={styles.createAccountSignContainer}
        onPress={() => navigation.navigate("HomeScreen1")}
      >
        <Text style={[styles.text, styles.logTypo]}>
          <Text style={styles.createAccount}>{`    Create account. `}</Text>
          <Text style={styles.signUp}>{`    
           Sign Up`}</Text>
        </Text>
      </Pressable>

      <Pressable
        style={styles.logInPressable}
        onPress={() => navigation.navigate("HomeScreen5")}
      ></Pressable>
      <Text style={[styles.logIn1, styles.logTypo]}>
        {`Log In
`}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  homeLayout: {
    height: 56,
    backgroundColor: Color.colorGainsboro,
    left: 23,
    width: 325,
    position: "absolute",
  },
  rectangleViewPosition: {
    left: 26,
    height: 56,
    position: "absolute",
  },
  logTypo: {
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
  },
  passwordTypo: {
    opacity: 0.5,
    color: Color.colorGray_200,
    fontSize: FontSize.size_3xl,
    left: 48,
    textAlign: "left",
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  homeScreenChild: {
    top: 406,
  },
  homeScreenItem: {
    top: 309,
  },
  homeScreenInner: {
    top: 492,
    backgroundColor: Color.coffeeRed,
    width: 146,
  },
  rectangleView: {
    top: 302,
    backgroundColor: "rgba(128, 128, 128, 0)",
    width: 325,
    left: 26,
  },
  logIn: {
    top: 510,
    left: 45,
    width: 245,
    height: 30,
    opacity: 0.7,
    color: Color.colorBlack,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.archivoBlackRegular,
    position: "absolute",
  },
  password: {
    top: 413,
    width: 231,
    height: 38,
  },
  emailAddress: {
    top: 318,
    width: 219,
    height: 31,
  },
  createAccount: {
    color: Color.colorBlack,
  },
  signUp: {
    color: Color.coffeeRed,
  },
  text: {
    width: 270,
    height: 58,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.archivoBlackRegular,
  },
  createAccountSignContainer: {
    top: 605,
    left: 48,
    position: "absolute",
  },
  logIn1: {
    top: 129,
    left: 126,
    fontSize: FontSize.size_11xl,
    width: 153,
    height: 39,
    color: Color.coffeeRed,
    position: "absolute",
  },
  homeScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.coffeeLight,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
  forgotPasswordLink: {
    top: 555,
    left: 25,
    position: "absolute",
  },
  forgotPasswordText: {
    color: Color.coffeeRed,
    textDecorationLine: "underline",
  },
});

export default HomeScreen2;
