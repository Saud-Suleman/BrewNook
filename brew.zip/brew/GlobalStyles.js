/* fonts */
export const FontFamily = {
  architectsDaughterRegular: "ArchitectsDaughter-Regular",
  poppinsMedium: "Poppins-Medium",
  archivoBlackRegular: "ArchivoBlack-Regular",
  poppinsSemiBold: "Poppins-SemiBold",
  poppinsRegular: "Poppins-Regular",
  poppinsBold: "Poppins-Bold",
};
/* font sizes */
export const FontSize = {
  size_11xl: 30,
  size_sm: 14,
  size_xl: 20,
  size_xs: 12,
  size_base: 16,
  size_3xl: 22,
  size_lg: 18,
  size_5xl: 24,
};
/* Colors */
export const Color = {
  coffeeRed: "#d1512d",
  colorBlack: "#000",
  white: "#fff",
  coffeeLight: "#f5e8e4",
  coffeeMud: "#f5c7a9",
  coffeDark: "#411530",
  colorGray_200: "#1b1b1b",
  colorGainsboro: "#d9d9d9",
};
/* border radiuses */
export const Border = {
  br_21xl: 40,
  br_base: 16,
  br_5xl: 24,
};
