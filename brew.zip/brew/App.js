// const Stack = createNativeStackNavigator();
// import * as React from "react";
// import { NavigationContainer } from "@react-navigation/native";
// import { useFonts } from "expo-font";
// import HomeScreen from "./screens/HomeScreen";
// import CartScreen from "./screens/CartScreen";
// import DetailsScreen from "./screens/DetailsScreen";
// import HomeScreen1 from "./screens/HomeScreen1";
// import HomeScreen2 from "./screens/HomeScreen2";
// import HomeScreen3 from "./screens/HomeScreen3";
// import HomeScreen4 from "./screens/HomeScreen4";
// import HomeScreen5 from "./screens/HomeScreen5";
// import Bord1 from "./screens/bord1";
// import Bord2 from "./screens/bord2";
// import PasswordReset from "./screens/PasswordReset";
// import PwdReseted from "./screens/PwdReseted";

// import { createNativeStackNavigator } from "@react-navigation/native-stack";
// import { View, Text, Pressable, TouchableOpacity } from "react-native";

// const App = () => {
//   const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

//   const [fontsLoaded, error] = useFonts({
//     "ArchitectsDaughter-Regular": require("./assets/fonts/ArchitectsDaughter-Regular.ttf"),
//     "ArchivoBlack-Regular": require("./assets/fonts/ArchivoBlack-Regular.ttf"),
//     "Poppins-Regular": require("./assets/fonts/Poppins-Regular.ttf"),
//     "Poppins-Medium": require("./assets/fonts/Poppins-Medium.ttf"),
//     "Poppins-SemiBold": require("./assets/fonts/Poppins-SemiBold.ttf"),
//     "Poppins-Bold": require("./assets/fonts/Poppins-Bold.ttf"),
//   });

//   if (!fontsLoaded && !error) {
//     return null;
//   }

//   return (
//     <>
//       <NavigationContainer>
//         {hideSplashScreen ? (
//           // <Stack.Navigator screenOptions={{ headerShown: false }}>
//           <
//             initialRouteName="Bord1"
//             screenOptions={{ headerShown: false }}
//           >
//             <Stack.Screen
//               name="HomeScreen"
//               component={HomeScreen}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen
//               name="CartScreen"
//               component={CartScreen}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen
//               name="DetailsScreen"
//               component={DetailsScreen}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen
//               name="HomeScreen1"
//               component={HomeScreen1}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen
//               name="HomeScreen2"
//               component={HomeScreen2}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen
//               name="HomeScreen3"
//               component={HomeScreen3}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen
//               name="HomeScreen4"
//               component={HomeScreen4}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen name="PasswordReset" component={PasswordReset} />

//             <Stack.Screen
//               name="HomeScreen5"
//               component={HomeScreen5}
//               options={{ headerShown: false }}
//             />
//             <Stack.Screen name="Bord1" component={Bord1} />
//             <Stack.Screen name="Bord2" component={Bord2} />

//           </Stack.Navigator>
//         ) : null}
//       </NavigationContainer>
//     </>
//   );
// };
// export default App;

import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View } from "react-native";
import HomeScreen from "./screens/HomeScreen";
import CartScreen from "./screens/CartScreen";
import DetailsScreen from "./screens/DetailsScreen";
import HomeScreen1 from "./screens/HomeScreen1";
import HomeScreen2 from "./screens/HomeScreen2";
import HomeScreen3 from "./screens/HomeScreen3";
import HomeScreen4 from "./screens/HomeScreen4";
import HomeScreen5 from "./screens/HomeScreen5";
import Bord1 from "./screens/bord1";
import Bord2 from "./screens/bord2";
import PasswordReset from "./screens/PasswordReset";
import PwdReseted from "./screens/PwdReseted";

const Stack = createNativeStackNavigator();

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "ArchitectsDaughter-Regular": require("./assets/fonts/ArchitectsDaughter-Regular.ttf"),
    "ArchivoBlack-Regular": require("./assets/fonts/ArchivoBlack-Regular.ttf"),
    "Poppins-Regular": require("./assets/fonts/Poppins-Regular.ttf"),
    "Poppins-Medium": require("./assets/fonts/Poppins-Medium.ttf"),
    "Poppins-SemiBold": require("./assets/fonts/Poppins-SemiBold.ttf"),
    "Poppins-Bold": require("./assets/fonts/Poppins-Bold.ttf"),
  });

  if (!fontsLoaded || error) {
    // Handle font loading error
    return null;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Bord1"
        screenOptions={{ headerShown: false }}
      >
        <Stack.Screen name="HomeScreen" component={HomeScreen} />
        <Stack.Screen name="CartScreen" component={CartScreen} />
        <Stack.Screen name="DetailsScreen" component={DetailsScreen} />
        <Stack.Screen name="HomeScreen1" component={HomeScreen1} />
        <Stack.Screen name="HomeScreen2" component={HomeScreen2} />
        <Stack.Screen name="HomeScreen3" component={HomeScreen3} />
        <Stack.Screen name="HomeScreen4" component={HomeScreen4} />
        <Stack.Screen name="PasswordReset" component={PasswordReset} />
        <Stack.Screen name="HomeScreen5" component={HomeScreen5} />
        <Stack.Screen name="Bord1" component={Bord1} />
        <Stack.Screen name="Bord2" component={Bord2} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
